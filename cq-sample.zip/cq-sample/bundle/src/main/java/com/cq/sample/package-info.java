@Version("1.0.0")
package com.cq.sample;

import aQute.bnd.annotation.Version;